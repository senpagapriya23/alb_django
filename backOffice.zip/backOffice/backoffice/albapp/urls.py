from django.urls import path
# from .views import index
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.index, name='index'),
    # path('add/', views.add_fire_situation, name='add_fire_situation'),
    path('update/<int:batch_id>/', views.update_fire_situation, name='update_fire_situation'),
    path('delete/<int:batch_id>/', views.delete_fire_situation, name='delete_fire_situation'),
    path('export_data/', views.export_data, name='export_data'),
]

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,
                              document_root=settings.MEDIA_ROOT)