from django.shortcuts import render,redirect, get_object_or_404
from .models import Batch, ShpMetadata, ImageMetadata, VideoMetadata
from .forms import ShapefileZipUploadForm, ImageUploadForm, VideoUploadForm
from django.conf import settings
from django.http import HttpResponse,HttpResponseBadRequest
from meteofrance_api.model import Place
from meteofrance_api.client import MeteoFranceClient
import requests
import boto3
import os
import tempfile,zipfile
import io
import json
from django.contrib.auth import authenticate, login
from .forms import AdminLoginForm

s3 = boto3.client(
    "s3",
    aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
    aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
    region_name=settings.AWS_S3_REGION_NAME
)
client = MeteoFranceClient()
api_key = "5c4b838e17ca43749d14bc52088723df"

def index(request):
    try:
        data = []
        status_options = set()
        tag_options = set()
        element_format_options = set()

        if request.method == "POST":
            print("post")
            zip_code = request.POST.get("zip_code")
            status = request.POST.get("status")
            tag = request.POST.get("tag")
            element_format = request.POST.get("element_format")
            fromdate = request.POST.get("fromdate")
            todate = request.POST.get("todate")
            
            if tag:
                batches = Batch.objects.filter(tags=tag)            
            elif status:
                batches = Batch.objects.filter(status=status)
                print(batches)
            elif fromdate and todate:
                batches = Batch.objects.filter(acquisition_date__range=[fromdate, todate])
            else:
                batches = Batch.objects.all().order_by("-id")

        else:
            batches = Batch.objects.all().order_by("-id")

        for batch in batches:
            fire_situation = {
                "id": batch.id,
                "status": batch.status,
                "unique_reference": [],
                # "unique_reference": f"FireSituation {batch.id}",
                "batch_name": batch.batch_name,
                "elements": [],
                "tags": batch.tags
            }

            if request.method == "POST" and element_format:
                shp_metadata = ShpMetadata.objects.filter(batch_id=batch.id).first()
                if shp_metadata:
                    geom = shp_metadata.geom
                    centroid = geom.centroid
                    
                    zipcode = get_zipcode_from_coordinates(centroid.y, centroid.x)
                    fire_situation["unique_reference"].append({"gps_coords": [centroid.y,centroid.x]})
                    if zipcode:
                        fire_situation["unique_reference"].append({"zipcode": zipcode})
                    print(fire_situation["unique_reference"])
                        
                if element_format == "Shapefile":
                    shp_metadata = ShpMetadata.objects.filter(batch_id=batch.id).first()
                    if shp_metadata:
                        fire_situation["elements"].append({"element_type": "Shapefile", "name": shp_metadata.file_name})

                elif element_format == "Image":
                    img_metadata_list = ImageMetadata.objects.filter(batch_id=batch.id)
                    for img_metadata in img_metadata_list:
                        fire_situation["elements"].append({"element_type": "Image", "name": img_metadata.file_name})

                elif element_format == "Video":
                    video_metadata = VideoMetadata.objects.filter(batch_id=batch.id).first()
                    if video_metadata:
                        fire_situation["elements"].append({"element_type": "Video", "name": video_metadata.file_name})

            else:                
                shp_metadata = ShpMetadata.objects.filter(batch_id=batch.id).first()
                if shp_metadata:
                    fire_situation["elements"].append({"element_type": "Shapefile", "name": shp_metadata.file_name})
                    geom = shp_metadata.geom
                    centroid = geom.centroid
                    
                    zipcode = get_zipcode_from_coordinates(centroid.y, centroid.x)
                    fire_situation["unique_reference"].append({"gps_coords": [centroid.y,centroid.x]})
                    if zipcode:
                        fire_situation["unique_reference"].append({"zipcode": zipcode})
                    print(fire_situation["unique_reference"])

                img_metadata_list = ImageMetadata.objects.filter(batch_id=batch.id)
                for img_metadata in img_metadata_list:
                    fire_situation["elements"].append({"element_type": "Image", "name": img_metadata.file_name})

                video_metadata = VideoMetadata.objects.filter(batch_id=batch.id).first()
                if video_metadata:
                    fire_situation["elements"].append({"element_type": "Video", "name": video_metadata.file_name})
                    
                if shp_metadata:    
                    fire_situation["elements"].append({"element_type": "Fire area", "name": float(shp_metadata.fire_area)})
                    if shp_metadata.fire_propagation == None:
                        shp_metadata.fire_propagation = 'null'
                        shp_metadata.fire_orientation = 'null'
                    fire_situation["elements"].append({"element_type": "Fire Propagation","name": shp_metadata.fire_propagation})
                    fire_situation["elements"].append({"element_type": "Fire Orientation", "name": shp_metadata.fire_orientation})

            data.append(fire_situation)
            
        for status in ["ONGOING","ENDED"]:
            status_options.add(status)

        for tag in ["Lab", "Field", "OP"]:
            tag_options.add(tag)

        for element in ["Shapefile","Image","Video"]:                
            element_format_options.add(element)
                
            # for element in fire_situation["elements"]:
            #     if "element_type" in element:
            #         if element["element_type"] not in ["Fire area", "Fire Propagation", "Fire Orientation"]:
            #             element_format_options.add(element["element_type"])

        return render(request, "index.html", {
            "data": data,
            "status_options": status_options,
            "tag_options": tag_options,
            "element_format_options": element_format_options
        })

    except Exception as error:
        print(error)
        return render(request, "index.html", {"data": []})

def handle_shapefile_upload(shapefile_zip, element_name, batch):
    with tempfile.TemporaryDirectory() as tmpdirname:
        with zipfile.ZipFile(shapefile_zip, "r") as zip_ref:
            zip_ref.extractall(tmpdirname)

        required_files = {".prj", ".dbf", ".shx", ".shp"}
        extracted_files = set(os.path.splitext(f)[1] for f in os.listdir(tmpdirname))

        if not required_files.issubset(extracted_files):
            return False, "The zip file must contain .prj, .dbf, .shx, and .shp files."

        for file in os.listdir(tmpdirname):
            file_path = os.path.join(tmpdirname, file)
            s3.upload_file(file_path, settings.AWS_STORAGE_BUCKET_NAME, f"shapefiles/{file}")

        base_name = os.path.splitext(element_name)[0]
        for ext in ['.shp', '.shx', '.dbf', '.prj']:
            s3_key = f"shapefiles/{base_name}{ext}"
            s3.delete_object(Bucket=settings.AWS_STORAGE_BUCKET_NAME, Key=s3_key)
            print(f'Deleted {s3_key} from {settings.AWS_STORAGE_BUCKET_NAME}')

        ShpMetadata.objects.filter(batch=batch, file_name=element_name).delete()
        return True, None

def handle_file_upload(file, file_type, batch, element_name):
    s3.upload_fileobj(file, settings.AWS_STORAGE_BUCKET_NAME, f"{file_type}/{file}")
    s3.delete_object(Bucket=settings.AWS_STORAGE_BUCKET_NAME, Key=f"{file_type}/{element_name}")

    if file_type == "images":
        ImageMetadata.objects.filter(batch=batch, file_name=element_name).delete()
    elif file_type == "videos":
        VideoMetadata.objects.filter(batch=batch, file_name=element_name).delete()

def update_fire_situation(request, batch_id):
    batch = get_object_or_404(Batch, id=batch_id)
    element_type = request.POST.get("element_type")    
    print("Filterd element_type:",element_type)
    
    shp_metadata = ShpMetadata.objects.filter(batch=batch).first()
    geom = shp_metadata.geom if shp_metadata else None
    centroid = geom.centroid if geom else None
    zipcode = get_zipcode_from_coordinates(centroid.y, centroid.x) if centroid else None
    
    shp_metadata = None
    image_metadata = None
    video_metadata = None
    image_metadata_count = 0
    video_metadata_count = 0
    shp_metadata_count = 0 
    
    fire_situation = {
        "elements": []
    }
        
    if element_type == "Image":
        image_metadata = ImageMetadata.objects.filter(batch=batch)
        image_metadata_count = image_metadata.count()
        for img_ in image_metadata:
            fire_situation["elements"].append({"element_type": "Image","name": img_.file_name})
    elif element_type == "Video":
        video_metadata = VideoMetadata.objects.filter(batch=batch).first()
        video_metadata_count = 1
        fire_situation["elements"].append({"element_type": "Video","name": video_metadata.file_name})
    elif element_type == "Shapefile":
        shp_metadata = ShpMetadata.objects.filter(batch=batch).first()
        shp_metadata_count = 1
        fire_situation["elements"].append({"element_type": "Shapefile","name": shp_metadata.file_name})        
    else:           
        image_metadata = ImageMetadata.objects.filter(batch=batch)
        shp_metadata = ShpMetadata.objects.filter(batch=batch).first()
        video_metadata = VideoMetadata.objects.filter(batch=batch).first()
        image_metadata_count = image_metadata.count()
        video_metadata_count = 1
        shp_metadata_count = 1
        fire_situation["elements"].append({"element_type": "Shapefile","name": shp_metadata.file_name}) 
        for img_ in image_metadata:
            fire_situation["elements"].append({"element_type": "Image","name": img_.file_name})
        fire_situation["elements"].append({"element_type": "Video","name": video_metadata.file_name})

    shapefile_zip_form = ShapefileZipUploadForm()
    image_form = ImageUploadForm()
    video_form = VideoUploadForm()

    if request.method == "POST":
        if "update_batch" in request.POST:
            update_batch_details(request, batch)

        elif "update_shapefile" in request.POST:
            element_name = request.POST['update_shapefile']
            shapefile_zip_form = ShapefileZipUploadForm(request.POST, request.FILES)
            if shapefile_zip_form.is_valid():
                shapefile_zip = shapefile_zip_form.cleaned_data["shapefile_zip"]
                success, error = handle_shapefile_upload(shapefile_zip, element_name, batch)
                if success:
                    return redirect("update_fire_situation", batch_id=batch_id)
                else:
                    shapefile_zip_form.add_error("shapefile_zip", error)

        elif "update_image" in request.POST:
            element_name = request.POST['update_image']
            image_form = ImageUploadForm(request.POST, request.FILES)
            if image_form.is_valid():
                handle_file_upload(image_form.cleaned_data["image"], "images", batch, element_name)
                return redirect("update_fire_situation", batch_id=batch_id)

        elif "update_video" in request.POST:
            element_name = request.POST['update_video']
            video_form = VideoUploadForm(request.POST, request.FILES)
            if video_form.is_valid():
                handle_file_upload(video_form.cleaned_data["video"], "videos", batch, element_name)
                return redirect("update_fire_situation", batch_id=batch_id)

        elif "delete_shapefile" in request.POST:
            handle_file_deletion(element_name, "shapefiles", ShpMetadata, batch)

        elif "delete_image" in request.POST:
            handle_file_deletion(element_name, "images", ImageMetadata, batch)

        elif "delete_video" in request.POST:
            handle_file_deletion(element_name, "videos", VideoMetadata, batch)
            
        elif "add_files" in request.POST:
            new_file = request.FILES.get('new_file')
            if new_file:
                print(new_file.name,new_file.content_type) 
                
                if new_file.content_type.startswith('image/'):
                    image_form = ImageUploadForm(request.POST, request.FILES)
                    if image_form.is_valid():
                        s3.upload_fileobj(new_file, settings.AWS_STORAGE_BUCKET_NAME, f"images/{new_file}")
                        return redirect("update_fire_situation", batch_id=batch_id)
                    
                elif new_file.content_type in ['application/zip', 'application/x-zip-compressed']:
                    with tempfile.TemporaryDirectory() as tmpdirname:
                        with zipfile.ZipFile(new_file, "r") as zip_ref:
                            zip_ref.extractall(tmpdirname)

                        required_files = {".prj", ".dbf", ".shx", ".shp"}
                        extracted_files = set(os.path.splitext(f)[1] for f in os.listdir(tmpdirname))

                        if not required_files.issubset(extracted_files):
                            shapefile_zip_form = ShapefileZipUploadForm()
                            shapefile_zip_form.add_error("shapefile_zip", "The zip file must contain .prj, .dbf, .shx, and .shp files.")
                            context = {
                                'shapefile_zip_form': shapefile_zip_form,
                                'image_form': ImageUploadForm(),
                                'video_form': VideoUploadForm(),
                            }
                            return render(request, 'your_template.html', context)

                        for file in os.listdir(tmpdirname):
                            file_path = os.path.join(tmpdirname, file)
                            s3.upload_file(file_path, settings.AWS_STORAGE_BUCKET_NAME, f"shapefiles/{file}")

                    return redirect("update_fire_situation", batch_id=batch_id)
                            
                elif new_file.content_type.startswith('video/'):
                    video_form = VideoUploadForm(request.POST, request.FILES)
                    if video_form.is_valid():                        
                        s3.upload_fileobj(new_file, settings.AWS_STORAGE_BUCKET_NAME, f"images/{new_file}")
                        return redirect("update_fire_situation", batch_id=batch_id)

    total_count = image_metadata_count + shp_metadata_count + video_metadata_count
    print("Total count of elements:", total_count)

    return render(request, "batch_detail.html", {
        "batch": batch,
        "image_metadata": image_metadata,
        "shp_metadata": shp_metadata,
        "video_metadata": video_metadata,
        "gps_coords": [centroid.y, centroid.x] if centroid else [],
        "zipcode": zipcode,
        "shapefile_zip_form": shapefile_zip_form,
        "image_form": image_form,
        "video_form": video_form,
        "element_type": element_type,
        "total_count": total_count,
        "fire_situation": fire_situation
    })

def update_batch_details(request, batch):
    status = request.POST.get("status")
    tags = request.POST.get("tags")
    if status:
        batch.status = status
    if tags:
        batch.tags = tags
    batch.save()

    update_metadata(request, batch, ImageMetadata, "image_element_")
    update_metadata(request, batch, VideoMetadata, "video_element_")
    update_metadata(request, batch, ShpMetadata, "shp_element_")

def update_metadata(request,batch, model, prefix):
    for obj in model.objects.filter(batch=batch):
        file_name = request.POST.get(f"{prefix}{obj.file_name}")
        if file_name:
            obj.file_name = file_name
            obj.save()

def handle_file_deletion(element_name, file_type, model, batch):
    s3.delete_object(Bucket=settings.AWS_STORAGE_BUCKET_NAME, Key=f"{file_type}/{element_name}")
    model.objects.filter(batch=batch, file_name=element_name).delete()
    print(f'Deleted {file_type}/{element_name} from {settings.AWS_STORAGE_BUCKET_NAME}')
    

def delete_fire_situation(request, batch_id):
    batch = get_object_or_404(Batch, id=batch_id) 
    image_metadata = ImageMetadata.objects.filter(batch=batch)
    image_metadata_count = image_metadata.count()
    shp_metadata = ShpMetadata.objects.filter(batch=batch).first()
    video_metadata = VideoMetadata.objects.filter(batch=batch).first()   
    if request.method == "POST":
        if "delete_batch" in request.POST:  
            bucket_name = settings.AWS_STORAGE_BUCKET_NAME
            prefixes = ["shapefiles/", "images/", "videos/"]
            
            for prefix in prefixes:
                if shp_metadata and prefix == 'shapefiles/':
                    base_name = shp_metadata.file_name.split('.')[0]
                    extensions = ['.shp', '.shx', '.dbf', '.prj']
                    for ext in extensions:
                        s3_key = f"{prefix}{base_name}{ext}" 
                        s3.delete_object(Bucket=bucket_name, Key=s3_key)
                        print(f'Deleted {s3_key} from {bucket_name}')
                        
                elif image_metadata_count > 0 and prefix == 'images/':
                    print(image_metadata)
                    for img_data in image_metadata:
                        print(image_metadata)                        
                        s3_key = f"{prefix}{img_data.file_name}"
                        s3.delete_object(Bucket=bucket_name, Key=s3_key)
                        print(f'Deleted {s3_key} from {bucket_name}')
                
                elif video_metadata and prefix == 'videos/':
                    s3_key = f"{prefix}{video_metadata.file_name}"
                    s3.delete_object(Bucket=bucket_name, Key=s3_key)
                    print(f'Deleted {s3_key} from {bucket_name}')
            
            batch.delete()
                
            return redirect('index')    
    return render(request, "confirm_delete.html", {'batch': batch})


def download_files_from_s3(s3, bucket_name, prefix, element_name, batch_name, zip_file, elementType):
    if elementType == "Shapefile":
        base_name = element_name.split('.')[0]
        extensions = ['.shp', '.shx', '.dbf', '.prj']
        for ext in extensions:
            s3_key = f"{prefix}{base_name}{ext}"
            try:
                file_obj = s3.get_object(Bucket=bucket_name, Key=s3_key)
                zip_file.writestr(f"{batch_name}/{base_name}{ext}", file_obj["Body"].read())
            except s3.exceptions.NoSuchKey:
                print(f"File {s3_key} not found in S3 bucket")
    else:
        s3_key = f"{prefix}{element_name}"
        try:
            file_obj = s3.get_object(Bucket=bucket_name, Key=s3_key)
            zip_file.writestr(f"{batch_name}/{element_name}", file_obj["Body"].read())
        except s3.exceptions.NoSuchKey:
            print(f"File {s3_key} not found in S3 bucket")

def export_data(request):
    element_type = request.POST.get("element_type")
    batch_data_str = request.POST.get("batch_data", "").replace("'", '"')

    try:
        batch_data = json.loads(batch_data_str)
    except json.JSONDecodeError as e:
        print("Error decoding JSON:", e)
        return HttpResponseBadRequest("Invalid batch_data format")
    
    bucket_name = settings.AWS_STORAGE_BUCKET_NAME

    if element_type == "Shapefile":
        prefix = "shapefiles/"
    elif element_type == "Image":
        prefix = "images/"
    elif element_type == "Video":
        prefix = "videos/"
    else:
        prefix = ["shapefiles/", "images/", "videos/"]

    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as zip_file:
        for batch in batch_data:
            batch_name = batch.get("batch_name")
            for element in batch.get("elements", []):
                elementType = element.get("element_type")
                element_name = element.get("name")
                
                if element_type is None or element_type == elementType:
                    if isinstance(prefix, list):
                        for prefx in prefix:
                            download_files_from_s3(s3, bucket_name, prefx, element_name, batch_name, zip_file, elementType)
                    else:
                        download_files_from_s3(s3, bucket_name, prefix, element_name, batch_name, zip_file, element_type)

    buffer.seek(0)
    content_disposition = f"attachment; filename={'AllBatches.zip' if element_type is None else f'{element_type}s.zip'}"
    response = HttpResponse(buffer, content_type="application/zip")
    response["Content-Disposition"] = content_disposition

    return response
    
    
    
    
    
    
    
    
    
    



# def get_zipcode_from_coordinates(lat, lon):
#     try:
#         place = Place({
#             "lat": float(46.2276),
#             "lon": float(2.2137)
#         })
#         print(place)
#         return place.postal_code
#     except Exception as e:
#         print(f"Error getting postal code: {e}")
#         return None
    
def get_zipcode_from_coordinates(lat, lon):
    url = f"https://api.opencagedata.com/geocode/v1/json?q={lat}+{lon}&key={api_key}"
    try:
        response = requests.get(url)
        response.raise_for_status()  # Raise an HTTPError for bad responses
        data = response.json()

        if "results" in data and len(data["results"]) > 0:
            for component in data["results"][0]["components"]:
                if "postcode" in data["results"][0]["components"]:
                    return data["results"][0]["components"]["postcode"]
        return None
    except requests.exceptions.RequestException as e:
        print(f"Error getting postal code: {e}")
        return None
    
    
    
    

# def add_fire_situation(request):
#     if request.method == "POST":
#         form = FireSituationForm(request.POST)
#         if form.is_valid():
#             form.save()
#             return redirect("index")
#     else:
#         form = FireSituationForm()
#     return render(request, "fire_situation_form.html", {"form": form})