from django.contrib import admin
from .models import Batch,ShpMetadata,VideoMetadata,ImageMetadata
# Register your models here.

admin.site.register(Batch)
admin.site.register(ShpMetadata)
admin.site.register(ImageMetadata)
admin.site.register(VideoMetadata)