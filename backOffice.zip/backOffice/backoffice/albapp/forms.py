from django import forms
from .models import Batch

class ShapefileZipUploadForm(forms.Form):
    shapefile_zip = forms.FileField(label='Upload Shapefile (ZIP)',required=False)

class ImageUploadForm(forms.Form):
    image = forms.ImageField(required=False)
    
class VideoUploadForm(forms.Form):
    video = forms.FileField(required=False)